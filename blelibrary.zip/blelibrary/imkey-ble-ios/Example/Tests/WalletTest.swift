//
//  ByteUtilTest.swift
//  imKeyConnector_Example
//
//  Created by joe on 11/23/18.
//  Copyright © 2018 CocoaPods. All rights reserved.
//

import XCTest
import imKeyConnector


class WalletTest: XCTestCase {
  func testToETHChecksumAddress(){
//    XCTAssertEqual("0x6031564e7b2F5cc33737807b2E58DaFF870B590b", try Wallet.toETHChecksumAddress(address: "6031564e7b2f5cc33737807b2e58daff870b590b"))
//    XCTAssertEqual("0x6031564e7b2F5cc33737807b2E58DaFF870B590b", try Wallet.toETHChecksumAddress(address: "0x6031564e7b2f5cc33737807b2e58daff870b590b"))
  }
}
