//
//  imKeyConnector.h
//  imKeyConnector
//
//  Created by xyz on 2018/9/17.
//

#import <UIKit/UIKit.h>

//! Project version number for ImkeyLibrary.
FOUNDATION_EXPORT double ImkeyLibraryVersionNumber;

//! Project version string for ImkeyLibrary.
FOUNDATION_EXPORT const unsigned char ImkeyLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImkeyLibrary/PublicHeader.h>

#import "FTBLEInterface.h"
#import "FTBLEDelegate.h"
//#import "secp256k1_ecdh.h"
//#import "main_impl.h"
//#import "CoreBitcoin/CoreBitcoin.h"
//#include <ErrorCodesAndMacro.h>
